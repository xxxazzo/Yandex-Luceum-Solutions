from flask import Flask, render_template
from data.users import User
from data.jobs import Jobs
from data import db_session
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def add_user(surname, name, age, position, speciality, address, email):
    user = User()
    user.surname = surname
    user.name = name
    user.age = age
    user.position = position
    user.speciality = speciality
    user.address = address
    user.email = email
    db_sess = db_session.create_session()
    db_sess.add(user)
    db_sess.commit()


def add_job(team_leader, job, work_size, collaborators, start_date, is_finished):
    new_job = Jobs()
    new_job.team_leader = team_leader
    new_job.job = job
    new_job.work_size = work_size
    new_job.collaborators = collaborators
    new_job.start_date = start_date
    new_job.is_finished = is_finished
    db_sess = db_session.create_session()
    db_sess.add(new_job)
    db_sess.commit()


@app.route('/')
def index():
    db_sess = db_session.create_session()

    jobs_list = list()
    for job in db_sess.query(Jobs):
        res = dict()
        res['title-of-activity'] = job.job.capitalize()
        team_leader = db_sess.query(User).filter(User.id == job.team_leader).first()
        res['team-leader'] = ' '.join([team_leader.surname, team_leader.name])
        res['duration'] = job.work_size
        res['list-of-collaborators'] = job.collaborators
        res['is-finished'] = job.is_finished
        jobs_list.append(res)
    return render_template('index.html', jobs_list=jobs_list)


def main():
    db_session.global_init("db/blogs.db")
    '''new_users = (('Scott', 'Ridley', 21, 'captain', 'research engineer', 'module_1', 'scott_cheif@mars.org'),
                 ('Tribbiani', 'Joey', 23, 'major', 'actor', 'module_2', 'tribbiani_friends@mars.org'),
                 ('Chandler', 'Bing', 24, 'major', 'humorist', 'module_2', 'bing_friends@mars.org'),
                 ('Monica', 'Geller', 22, 'major', 'cook', 'module_2', 'monica_friends@mars.org'))
    for new_user in new_users:
        add_user(*new_user)
    add_job(1, 'deployment of residential modules 1 and 2', 15,
            '2, 3', datetime.now(), False)
    add_job(2, 'exploration of mineral resources', 15,
            '4, 3', datetime.now(), False)
    add_job(3, 'development of management system', 25,
            '5', datetime.now(), False)'''
    app.run()


if __name__ == '__main__':
    main()
