from flask import Flask, render_template, redirect
from loginform import LoginForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/training/<prof>')
def training(prof):
    return render_template('training.html', prof=prof, title=prof)


@app.route('/list_prof/<list>')
def list_prof(list):
    jobs = ['Инженер-исследователь',
            'Пилот',
            'Строитель',
            'Экзобиолог',
            'Врач',
            'Инженер по терраформированию',
            'Климатолог',
            'Специалист по радиационной защите',
            'Астрогеолог',
            'Гляциолог',
            'Инженер жизнеобеспечения',
            'Метеоролог',
            'Оператор марсохода',
            'Киберинженер',
            'Штурман',
            'Пилот дронов',
            'Строитель']
    return render_template('list_prof.html', jobs=jobs, list_type=list)


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    answer_dict = {'title': 'AUTO ANSWER',
                   'surname': 'Watny',
                   'name': 'Mark',
                   'education': 'выше среднего',
                   'profession': 'штурман марсохода',
                   'sex': 'male',
                   'motivation': 'Всегда мечтал застрять на Марсе!',
                   'ready': True}

    return render_template('auto_answer.html', **answer_dict)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('login.html', title='По каютам!', form=form)


@app.route('/success')
def success():
    return 'SUCCESS'


@app.route('/distribution')
def distribution():
    astronauts = ['Travis Scott', 'Lil Uzi Vert', '21 Savage', 'Playboi Carti', 'Yeat', 'Ken Carson']
    return render_template('distribution.html', astronauts=astronauts)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
