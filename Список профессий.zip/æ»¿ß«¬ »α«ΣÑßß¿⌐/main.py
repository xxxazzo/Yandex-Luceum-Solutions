from flask import Flask, render_template

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/training/<prof>')
def training(prof):
    return render_template('training.html', prof=prof, title=prof)


@app.route('/list_prof/<list>')
def list_prof(list):
    jobs = ['Инженер-исследователь',
            'Пилот',
            'Строитель',
            'Экзобиолог',
            'Врач',
            'Инженер по терраформированию',
            'Климатолог',
            'Специалист по радиационной защите',
            'Астрогеолог',
            'Гляциолог',
            'Инженер жизнеобеспечения',
            'Метеоролог',
            'Оператор марсохода',
            'Киберинженер',
            'Штурман',
            'Пилот дронов',
            'Строитель']
    return render_template('list_prof.html', jobs=jobs, list_type=list)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
