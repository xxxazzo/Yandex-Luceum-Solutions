from flask import Flask, url_for, request

app = Flask(__name__)


@app.route('/')
def main():
    return 'Миссия Колонизация Марса'


@app.route('/index')
def index():
    return 'И на Марсе будут яблони цвести!'


@app.route('/promotion')
def promotion():
    return '<br>'.join(['Человечество вырастает из детства.',
                        'Человечеству мала одна планета.',
                        'Мы сделаем обитаемыми безжизненные пока планеты.',
                        'И начнем с Марса!',
                        'Присоединяйся!'])


@app.route('/image_mars')
def image_mars():
    return f'''<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Привет, Марс!</title>
  </head>
  <body>
    <h1>Жди нас, Марс!</h1>
    <figure>
      <img
        src="{url_for('static', filename='img/mars.jpg')}"
        width="400"
        height="400"
      />
      <figcaption>Вот она какая, красная планета.</figcaption>
    </figure>
  </body>
</html>
'''


@app.route('/promotion_image')
def promotion_image():
    return f'''<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
      integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
    <title>Привет, Марс!</title>
  </head>
  <body>
    <h1>Жди нас, Марс!</h1>
    <img
      src="{url_for('static', filename='img/mars.jpg')}"
      width="400"
      height="400"
    />
    <div class="alert alert-dark" role="alert">
      Человечество вырастает из детства.
    </div>
    <div class="alert alert-success" role="alert">
      Человечеству мала одна планета.
    </div>
    <div class="alert alert-secondary" role="alert">
      Мы сделаем обитаемыми безжизненные пока планеты.
    </div>
    <div class="alert alert-warning" role="alert">И начнем с Марса!</div>
    <div class="alert alert-danger" role="alert">Присоединяйся!</div>
  </body>
</html>
'''


@app.route('/astronaut_selection', methods=['POST', 'GET'])
def form_sample():
    if request.method == 'GET':
        return f'''<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
      integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
    <title>Пример формы</title>
  </head>
  <body>
    <div style="line-height: 0px">
      <h1 style="color: black; text-align: center">Анкета претендента</h1>
      <br />
      <h2 style="color: black; text-align: center">на участие в миссии</h2>
    </div>
    <div>
      <form class="login_form" method="post">
        <input
          type="surname"
          class="form-control"
          id="surname"
          aria-describedby="surname"
          placeholder="Введите фамилию"
          name="surname"
        />
        <input
          type="name"
          class="form-control"
          id="name"
          aria-describedby="name"
          placeholder="Введите имя"
          name="name"
        />
        <br />
        <input
          type="email"
          class="form-control"
          id="email"
          aria-describedby="email"
          placeholder="Введите адрес почты"
          name="email"
        />
        <div class="form-group">
          <label for="educationSelect">Какое у вас образование?</label>
          <select class="form-control" id="educationSelect" name="education">
            <option>Начальное</option>
            <option>Основное</option>
            <option>Среднее</option>
            <option>Среднее профисиональное</option>
            <option>Высшее(бакалавриат)</option>
            <option>Высшее(магистратура)</option>
          </select>
        </div>
        <br />
        <div class="form-group">
          <label for="jobSelect">Какие у Вас профессии?</label><br />
          <input
            type="checkbox"
            id="job"
            name="инженер-исследователь"
            value="Инженер-исследователь"
          />
          <label class="form-check-label" for="job">Инженер-исследователь</label
          ><br />
          <input type="checkbox" id="job" name="пилот" value="Пилот" />
          <label class="form-check-label" for="job">Пилот</label><br />
          <input type="checkbox" id="job" name="строитель" value="Строитель" />
          <label class="form-check-label" for="job">Строитель</label><br />
          <input
            type="checkbox"
            id="job"
            name="экзобиолог"
            value="Экзобиолог"
          />
          <label class="form-check-label" for="job">Экзобиолог</label><br />
          <input type="checkbox" id="job" name="врач" value="Врач" />
          <label class="form-check-label" for="job">Врач</label><br />
          <input
            type="checkbox"
            id="job"
            name="инженер по терраформированию"
            value="Инженер по терраформированию"
          />
          <label class="form-check-label" for="job"
            >Инженер по терраформированию</label
          ><br />
          <input
            type="checkbox"
            id="job"
            name="климатолог"
            value="Климатолог"
          />
          <label class="form-check-label" for="job">Климатолог</label><br />
          <input
            type="checkbox"
            id="job"
            name="специалист по радиационной защите"
            value="Специалист по радиационной защите"
          />
          <label class="form-check-label" for="job"
            >Специалист по радиационной защите</label
          ><br />
          <input
            type="checkbox"
            id="job"
            name="астрогеолог"
            value="Астрогеолог"
          />
          <label class="form-check-label" for="job">Астрогеолог</label><br />
          <input type="checkbox" id="job" name="гляциолог" value="Гляциолог" />
          <label class="form-check-label" for="job">Гляциолог</label><br />
          <input
            type="checkbox"
            id="job"
            name="инженер жизнеобеспечения"
            value="Инженер жизнеобеспечения"
          />
          <label class="form-check-label" for="job"
            >Инженер жизнеобеспечения</label
          ><br />
          <input
            type="checkbox"
            id="job"
            name="метеоролог"
            value="Метеоролог"
          />
          <label class="form-check-label" for="job">Метеоролог</label><br />
          <input
            type="checkbox"
            id="job"
            name="оператор марсохода"
            value="Оператор марсохода"
          />
          <label class="form-check-label" for="job">Оператор марсохода</label
          ><br />
          <input
            type="checkbox"
            id="job"
            name="киберинженер"
            value="Киберинженер"
          />
          <label class="form-check-label" for="job">Киберинженер</label><br />
          <input type="checkbox" id="job" name="штурман" value="Штурман" />
          <label class="form-check-label" for="job">Штурман</label><br />
          <input
            type="checkbox"
            id="job"
            name="пилот дронов"
            value="Пилот дронов"
          />
          <label class="form-check-label" for="job">Пилот дронов</label><br />
        </div>
        <br />
        <div class="form-group">
          <label for="form-check">Укажите пол</label>
          <div class="form-check">
            <input
              class="form-check-input"
              type="radio"
              name="sex"
              id="male"
              value="male"
              checked
            />
            <label class="form-check-label" for="male"> Мужской </label>
          </div>
          <div class="form-check">
            <input
              class="form-check-input"
              type="radio"
              name="sex"
              id="female"
              value="female"
            />
            <label class="form-check-label" for="female"> Женский </label>
          </div>
        </div>
        <br />
        <div class="form-group">
          <label for="motivation"
            >Почему вы хотите принять участие в миссии</label
          >
          <textarea
            class="form-control"
            id="motivation"
            rows="3"
            name="motivation"
          ></textarea>
        </div>
        <br />
        <div class="form-group">
          <label for="photo">Приложите фотографию</label>
          <input type="file" class="form-control-file" id="photo" name="file" />
        </div>
        <br />
        <div class="form-group form-check">
          <input
            type="checkbox"
            class="form-check-input"
            id="acceptRules"
            name="accept"
          />
          <label class="form-check-label" for="acceptRules"
            >Готовы остаться на Марсе?</label
          >
        </div>
        <br />
        <button type="submit" class="btn btn-primary">Записаться</button>
      </form>
    </div>
  </body>
</html>
'''
    elif request.method == 'POST':
        print('*-------New applicant-------*')
        print('surname:', request.form.get('surname', '-'))
        print('name:', request.form.get('name', '-'))
        print('email:', request.form.get('email', '-'))
        print('education:', request.form.get('education', '-'))
        print('jobs:')
        jobs = ["инженер-исследователь", "пилот", "строитель", "экзобиолог", "врач", "инженер по терраформированию",
                "климатолог", "специалист по радиационной защите", "астрогеолог", "гляциолог",
                "инженер жизнеобеспечения", "метеоролог", "оператор марсохода", "киберинженер", "штурман",
                "пилот дронов"]
        print(' -', '\n - '.join(list(filter(lambda x: x, map(lambda x: request.form.get(x, False), jobs)))))
        print('gender:', request.form.get('sex', '-'))
        print('motivation:', request.form.get('motivation', '-'))
        print('Готовы ли остаться на Марсе?', {'on': 'Yes', 'off': 'No'}[request.form.get('accept', 'off')])
        print()
        return '<h1 style="text-align: center;">Форма отправлена</h1>'


@app.route('/choice/<planet_name>')
def choice(planet_name):
    planets_advantages = {'Меркурий': ['Много солнечной энергии;',
                                       'На полюсах колебания температур при смене дня и ночи не так ощутимы;',
                                       'Для строительства баз могут быть использованы местные материалы;',
                                       'Гравитация выше лунной вдвое;'],
                          'Венера': ['Эта планета ближайшая к Земле;',
                                     'Атмосфера поможет с торможением;',
                                     'Её ионосфера защитит от радиации;',
                                     'На ней можно жить в небе;'],
                          'Марс': ['Эта планета близка к Земле;',
                                   'На ней много необходимых ресурсов;',
                                   'На ней есть вода и атмосфера;',
                                   'На ней есть небольшое магнитное поле;'],
                          'Юпитер': ['Планета полностью непригодна для колонизации'],
                          'Сатурн': ['Планета полностью непригодна для колонизации'],
                          'Уран': ['Планета полностью непригодна для колонизации'],
                          'Нептун': ['Планета полностью непригодна для колонизации']}
    planet_info = planets_advantages.get(planet_name, ['Планета не найдена'])
    alerts = ['''<div class="alert alert-danger" role="alert">
    <h2>{}</h2>
    </div>''',
              '''<div class="alert alert-success" role="alert">
              <h2>{}</h2>
              </div>''',
              '''<div class="alert alert-warning" role="alert">
              <h2>{}</h2>
              </div>''',
              '''<div class="alert alert-info" role="alert">
              <h2>{}</h2>
              </div>''']
    html = '''<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <link rel="stylesheet" href="static/css/style.css">
    <title>Варианты выбора</title>
</head>
<body>
<h1>Моё предложение: {}</h1>
{}
</body>
</html>'''
    res_html = ''
    for i in range(len(planet_info)):
        res_html += alerts[i].format(planet_info[i]) + '\n'
    return html.format(planet_name, res_html)


@app.route('/results/<nickname>/<int:level>/<float:rating>')
def results(nickname, level, rating):
    return f'''<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <link rel="stylesheet" href="static/css/style.css">
    <title>Результаты отбора</title>
</head>
<body>
<h1>Результаты отбора</h1>
<h1>Претендента на участие в миссии {nickname}:</h1>
<div class="alert alert-success" role="alert">
    <h2>Поздравляем! Ваш рейтинг после {level} этапа отбора</h2>
</div>
<div class="alert alert-info" role="alert">
<h2>составляет {rating}</h2>
</div>
<div class="alert alert-warning" role="alert">
<h2>Желаем удачи!</h2>
</div>
</body>
</html>'''


@app.route('/carousel')
def load_photo():
    return '''<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <link rel="stylesheet" href="static/css/style.css">
    <title>Пейзажи Марса</title>
</head>
<body>
<h1 style="text-align: center;">Пейзажи марса</h1>
<div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <center><img src="static/img/mars1.jpg" class="d-block w-90" alt="..."></center>
    </div>
    <div class="carousel-item">
      <center><img src="static/img/mars2.jpg" class="d-block w-90" alt="..."></center>
    </div>
    <div class="carousel-item">
      <center><img src="static/img/mars3.jpg" class="d-block w-90" alt="..."></center>
    </div>
    <div class="carousel-item">
      <center><img src="static/img/mars4.jpg" class="d-block w-90" alt="..."></center>
    </div>
    <div class="carousel-item">
      <center><img src="static/img/mars5.jpg" class="d-block w-90" alt="..."></center>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
  </button>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
