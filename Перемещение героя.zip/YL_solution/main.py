import pygame
import sys
import os

all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
size = WIDTH, HEIGHT = 550, 550


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = pygame.image.load(fullname)
    return image


def terminate():
    pygame.quit()
    sys.exit()


def start_screen(screen):
    intro_text = ["Перемещение героя",
                  "Нажмите на клавишу мыши",
                  "или клавиатуры для продолжения"]
    fon = pygame.transform.scale(load_image('fon.jpg', (0, 0, 0)), (WIDTH, HEIGHT - 200))
    screen.blit(fon, (0, 200))
    font = pygame.font.Font(None, 40)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()


tile_width = tile_height = 50


class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        if tile_type == 'wall':
            self.image = load_image('box.png')
        elif tile_type == 'empty':
            self.image = load_image('grass.png')
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)


class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = load_image('mario.png')
        self.x, self.y = pos_x, pos_y
        self.rect = self.image.get_rect().move(
            tile_width * pos_x + 15, tile_height * pos_y + 5)

    def update_position(self, dirs):
        new_x, new_y = self.x + dirs[0], self.y + dirs[1]
        if new_x in range(level_x) and new_y in range(level_y) and level_map[new_y][new_x] == '.':
            self.x += dirs[0]
            self.y += dirs[1]
            self.rect.x += dirs[0] * tile_width
            self.rect.y += dirs[1] * tile_height


def level_map_converter_from_file(filename):
    with open(os.path.join('data', filename)) as file:
        level = [line.replace('\n', '') for line in file.readlines()]
    return level


def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Tile('empty', x, y)
            elif level[y][x] == '#':
                Tile('wall', x, y)
            elif level[y][x] == '@':
                Tile('empty', x, y)
                new_player = Player(x, y)
    # вернем игрока, а также размер поля в клетках
    return new_player, x, y


pygame.init()
pygame.font.init()
screen = pygame.display.set_mode(size)
start_screen(screen)
level_map = level_map_converter_from_file('map1.txt')
player, level_x, level_y = generate_level(level_map)
running = True
while running:
    screen.fill((0, 0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            player.update_position({80: (-1, 0), 79: (1, 0), 82: (0, -1), 81: (0, 1)}.get(event.scancode, (0, 0)))
    tiles_group.draw(screen)
    player_group.draw(screen)
    pygame.display.flip()
pygame.quit()
